package main

func main() {
	notafunc()
}
