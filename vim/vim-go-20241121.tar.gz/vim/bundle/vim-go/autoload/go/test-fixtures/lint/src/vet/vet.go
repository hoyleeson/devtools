package main

import "fmt"

func main() {
	str := "hello world!"
	fmt.Printf("%d\n", str)
}
